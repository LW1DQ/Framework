"""
Módulo de utilidades del Sistema A2A
"""

from .state import AgentState

__all__ = ['AgentState']
